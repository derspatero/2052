/** Automatically generated file. DO NOT MODIFY */
package ca.comp2052.a00892244;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}