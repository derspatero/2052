/** Automatically generated file. DO NOT MODIFY */
package com.example.ca.bcit.comp2052.a00892244.androidhelloworld;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}