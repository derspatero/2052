/** Automatically generated file. DO NOT MODIFY */
package ca.bcit.comp2052.edwardlambke;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}